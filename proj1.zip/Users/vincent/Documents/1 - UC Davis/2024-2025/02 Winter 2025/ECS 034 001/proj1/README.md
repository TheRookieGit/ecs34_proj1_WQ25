https://makefiletutorial.com
https://stackoverflow.com/questions/3220277/what-do-the-makefile-symbols-and-mean
https://google.github.io/googletest/reference/assertions.html
https://en.cppreference.com/w/cpp/container/vector
https://cplusplus.com/reference/cctype/toupper/
https://www.geeksforgeeks.org/unsigned-char-in-c-with-examples/
https://www.geeksforgeeks.org/static_cast-in-cpp/
https://stackoverflow.com/questions/59813602/how-can-i-use-the-toupper-or-tolower-function-on-a-string-array
https://gist.github.com/wuflower/fcb3e7018d1162d3cce09f4a8016664b
https://www.geeksforgeeks.org/string-find-in-cpp/

Referenced my own work from last year: only to draw inspiration of test examples(stringutiltest.cpp), did not copy them